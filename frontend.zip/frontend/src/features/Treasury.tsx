import React from 'react';
import { useQuery } from 'react-query';
import axios from 'axios';
import { Plus, Search, Wallet, ArrowUpRight, ArrowDownLeft } from 'lucide-react';

const fetchTreasury = async () => {
  const { data } = await axios.get('http://localhost:5000/api/treasury');
  return data;
};

const Treasury = () => {
  const { data: movements, isLoading } = useQuery('treasury', fetchTreasury);

  const balance = movements?.reduce((acc: number, m: any) => 
    m.type === 'in' ? acc + m.amount : acc - m.amount, 0) || 0;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold dark:text-white">Treasury (Cash)</h2>
        <div className="flex gap-2">
          <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2">
            <ArrowUpRight size={20} />
            Cash In
          </button>
          <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center gap-2">
            <ArrowDownLeft size={20} />
            Cash Out
          </button>
        </div>
      </div>

      <div className="bg-primary text-white p-8 rounded-2xl shadow-lg shadow-primary/20 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <div className="p-4 bg-white/20 rounded-2xl">
            <Wallet size={40} />
          </div>
          <div>
            <p className="text-white/70 text-sm font-medium">Current Cash Balance</p>
            <p className="text-4xl font-bold mt-1">${balance.toLocaleString()}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-white/70 text-sm">Last transaction</p>
          <p className="font-medium">{movements?.[0]?.date || 'No transactions'}</p>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
        <div className="p-6 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center">
          <h3 className="text-lg font-bold dark:text-white">Transaction History</h3>
          <div className="relative w-64">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Search history..."
              className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg py-2 pr-10 pl-4 focus:ring-2 focus:ring-primary outline-none text-sm"
            />
          </div>
        </div>
        <table className="w-full text-right">
          <thead className="bg-gray-50 dark:bg-gray-700/50">
            <tr>
              <th className="px-6 py-4 font-semibold text-sm">Number</th>
              <th className="px-6 py-4 font-semibold text-sm">Date</th>
              <th className="px-6 py-4 font-semibold text-sm">Type</th>
              <th className="px-6 py-4 font-semibold text-sm">Reference</th>
              <th className="px-6 py-4 font-semibold text-sm">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
            {isLoading ? (
              <tr><td colSpan={5} className="px-6 py-12 text-center">Loading...</td></tr>
            ) : movements?.length > 0 ? (
              movements.map((m: any) => (
                <tr key={m.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium">{m.number}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{m.date}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`flex items-center gap-1 ${m.type === 'in' ? 'text-green-600' : 'text-red-600'}`}>
                      {m.type === 'in' ? <ArrowUpRight size={14} /> : <ArrowDownLeft size={14} />}
                      {m.type === 'in' ? 'Income' : 'Expense'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">{m.reference || '-'}</td>
                  <td className={`px-6 py-4 text-sm font-bold ${m.type === 'in' ? 'text-green-600' : 'text-red-600'}`}>
                    {m.type === 'in' ? '+' : '-'}${m.amount.toLocaleString()}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-gray-500">No treasury movements found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Treasury;
