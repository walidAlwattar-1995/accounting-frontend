import React from 'react';
import { useQuery } from 'react-query';
import axios from 'axios';
import { Plus, Search, FolderTree, FileText } from 'lucide-react';

const fetchAccounts = async () => {
  const { data } = await axios.get('http://localhost:5000/api/accounts');
  return data;
};

const ChartOfAccounts = () => {
  const { data: accounts, isLoading } = useQuery('accounts', fetchAccounts);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold dark:text-white">Chart of Accounts</h2>
        <button className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-dark transition-colors flex items-center gap-2">
          <Plus size={20} />
          New Account
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
        <div className="relative max-w-md">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Search accounts by name or code..."
            className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg py-2 pr-10 pl-4 focus:ring-2 focus:ring-primary outline-none text-sm"
          />
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
        <table className="w-full text-right">
          <thead className="bg-gray-50 dark:bg-gray-700/50">
            <tr>
              <th className="px-6 py-4 font-semibold text-sm">Code</th>
              <th className="px-6 py-4 font-semibold text-sm">Account Name</th>
              <th className="px-6 py-4 font-semibold text-sm">Type</th>
              <th className="px-6 py-4 font-semibold text-sm">Balance</th>
              <th className="px-6 py-4 font-semibold text-sm">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
            {isLoading ? (
              <tr><td colSpan={5} className="px-6 py-12 text-center">Loading...</td></tr>
            ) : accounts?.length > 0 ? (
              accounts.map((acc: any) => (
                <tr key={acc.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                  <td className="px-6 py-4 text-sm font-mono">{acc.code}</td>
                  <td className="px-6 py-4 text-sm font-medium">{acc.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{acc.type}</td>
                  <td className="px-6 py-4 text-sm font-bold">${acc.balance.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      acc.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {acc.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-gray-500">No accounts found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ChartOfAccounts;
