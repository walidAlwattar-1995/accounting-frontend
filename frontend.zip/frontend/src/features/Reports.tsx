import React from 'react';
import { useQuery } from 'react-query';
import axios from 'axios';
import { BarChart3, FileText, Download, Printer, Calendar } from 'lucide-react';

const fetchTrialBalance = async () => {
  const { data } = await axios.get('http://localhost:5000/api/reports/trial-balance');
  return data;
};

const Reports = () => {
  const { data: trialBalance, isLoading } = useQuery('trial-balance', fetchTrialBalance);

  const totalDebit = trialBalance?.reduce((acc: number, row: any) => acc + (row.total_debit || 0), 0) || 0;
  const totalCredit = trialBalance?.reduce((acc: number, row: any) => acc + (row.total_credit || 0), 0) || 0;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold dark:text-white">Financial Reports</h2>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            <Calendar size={18} />
            Date Range
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary-dark transition-colors">
            <Printer size={18} />
            Print All
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { name: 'Trial Balance', icon: BarChart3, desc: 'Summary of all ledger balances' },
          { name: 'Profit & Loss', icon: FileText, desc: 'Income and expenses overview' },
          { name: 'Balance Sheet', icon: FileText, desc: 'Assets, liabilities, and equity' },
        ].map((report) => (
          <div key={report.name} className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 hover:border-primary transition-colors cursor-pointer group">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-primary/10 text-primary rounded-lg group-hover:bg-primary group-hover:text-white transition-colors">
                <report.icon size={24} />
              </div>
              <Download size={18} className="text-gray-400" />
            </div>
            <h3 className="font-bold dark:text-white">{report.name}</h3>
            <p className="text-sm text-gray-500 mt-1">{report.desc}</p>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
        <div className="p-6 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center">
          <h3 className="text-lg font-bold dark:text-white">Trial Balance Report</h3>
          <button className="text-primary text-sm font-medium flex items-center gap-1">
            <Download size={16} />
            Export CSV
          </button>
        </div>
        <table className="w-full text-right">
          <thead className="bg-gray-50 dark:bg-gray-700/50">
            <tr>
              <th className="px-6 py-4 font-semibold text-sm">Code</th>
              <th className="px-6 py-4 font-semibold text-sm">Account Name</th>
              <th className="px-6 py-4 font-semibold text-sm w-40">Debit</th>
              <th className="px-6 py-4 font-semibold text-sm w-40">Credit</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
            {isLoading ? (
              <tr><td colSpan={4} className="px-6 py-12 text-center">Loading...</td></tr>
            ) : trialBalance?.length > 0 ? (
              <>
                {trialBalance.map((row: any) => (
                  <tr key={row.code} className="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                    <td className="px-6 py-4 text-sm font-mono">{row.code}</td>
                    <td className="px-6 py-4 text-sm">{row.name}</td>
                    <td className="px-6 py-4 text-sm font-medium text-green-600">
                      {row.total_debit > 0 ? `$${row.total_debit.toLocaleString()}` : '-'}
                    </td>
                    <td className="px-6 py-4 text-sm font-medium text-red-600">
                      {row.total_credit > 0 ? `$${row.total_credit.toLocaleString()}` : '-'}
                    </td>
                  </tr>
                ))}
                <tr className="bg-gray-50 dark:bg-gray-700/50 font-bold">
                  <td colSpan={2} className="px-6 py-4 text-sm">Total</td>
                  <td className="px-6 py-4 text-sm text-green-600">${totalDebit.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm text-red-600">${totalCredit.toLocaleString()}</td>
                </tr>
              </>
            ) : (
              <tr>
                <td colSpan={4} className="px-6 py-12 text-center text-gray-500">No data available</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Reports;
