import React from 'react';
import { Save, Building2, Hash, Globe, Shield, Bell } from 'lucide-react';

const Settings = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold dark:text-white">Settings</h2>
        <button className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-primary-dark transition-colors flex items-center gap-2 shadow-lg shadow-primary/20">
          <Save size={20} />
          Save Changes
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="space-y-1">
          <h3 className="font-bold dark:text-white">Company Profile</h3>
          <p className="text-sm text-gray-500">Manage your business details and branding.</p>
        </div>
        <div className="md:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 space-y-4">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-20 h-20 bg-gray-100 dark:bg-gray-700 rounded-xl flex items-center justify-center text-gray-400 border-2 border-dashed border-gray-300 dark:border-gray-600">
              <Building2 size={32} />
            </div>
            <button className="text-primary text-sm font-medium hover:underline">Upload Logo</button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-500 uppercase">Company Name</label>
              <input type="text" defaultValue="My Business Ltd" className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-primary text-sm" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-500 uppercase">Tax Number</label>
              <input type="text" defaultValue="123-456-789" className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-primary text-sm" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="space-y-1">
          <h3 className="font-bold dark:text-white">Auto-Numbering</h3>
          <p className="text-sm text-gray-500">Configure prefixes for your documents.</p>
        </div>
        <div className="md:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 space-y-4">
          {[
            { label: 'Sales Invoices', prefix: 'INV-', icon: Hash },
            { label: 'Purchase Invoices', prefix: 'PUR-', icon: Hash },
            { label: 'Journal Entries', prefix: 'JV-', icon: Hash },
          ].map((item) => (
            <div key={item.label} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/30 rounded-lg">
              <div className="flex items-center gap-3">
                <item.icon size={18} className="text-gray-400" />
                <span className="text-sm font-medium dark:text-gray-300">{item.label}</span>
              </div>
              <input type="text" defaultValue={item.prefix} className="w-24 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded px-2 py-1 text-sm outline-none focus:ring-1 focus:ring-primary" />
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="space-y-1">
          <h3 className="font-bold dark:text-white">System & Security</h3>
          <p className="text-sm text-gray-500">Regional settings and access control.</p>
        </div>
        <div className="md:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Globe size={20} className="text-gray-400" />
              <div>
                <p className="text-sm font-medium dark:text-gray-300">Base Currency</p>
                <p className="text-xs text-gray-500">USD ($)</p>
              </div>
            </div>
            <button className="text-primary text-sm font-medium">Change</button>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield size={20} className="text-gray-400" />
              <div>
                <p className="text-sm font-medium dark:text-gray-300">Backup & Restore</p>
                <p className="text-xs text-gray-500">Last backup: 2 hours ago</p>
              </div>
            </div>
            <button className="bg-gray-100 dark:bg-gray-700 px-4 py-1.5 rounded-lg text-sm font-medium hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">Backup Now</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
