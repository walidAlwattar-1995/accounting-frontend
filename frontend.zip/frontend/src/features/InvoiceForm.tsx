import React, { useState, useEffect } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Plus, Trash2, Save, X, Printer, Barcode } from 'lucide-react';
import axios from 'axios';
import { toast } from 'react-hot-toast';

const invoiceSchema = z.object({
  number: z.string().min(1, 'Invoice number is required'),
  date: z.string().min(1, 'Date is required'),
  customer_id: z.number().optional(),
  payment_method: z.enum(['cash', 'partial', 'credit']),
  notes: z.string().optional(),
  lines: z.array(z.object({
    product_id: z.number(),
    description: z.string().optional(),
    qty: z.number().min(1),
    unit_price: z.number().min(0),
    discount_pct: z.number().default(0),
    tax_pct: z.number().default(0),
    line_total: z.number()
  })).min(1, 'At least one item is required')
});

type InvoiceFormValues = z.infer<typeof invoiceSchema>;

const InvoiceForm = ({ onClose, onSuccess }: { onClose: () => void, onSuccess: () => void }) => {
  const { register, control, handleSubmit, watch, setValue, formState: { errors } } = useForm<InvoiceFormValues>({
    resolver: zodResolver(invoiceSchema),
    defaultValues: {
      number: `INV-${Date.now().toString().slice(-4)}`,
      date: new Date().toISOString().split('T')[0],
      payment_method: 'cash',
      lines: [{ product_id: 1, description: '', qty: 1, unit_price: 0, discount_pct: 0, tax_pct: 0, line_total: 0 }]
    }
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'lines'
  });

  const lines = watch('lines');

  useEffect(() => {
    lines.forEach((line, index) => {
      const subtotal = line.qty * line.unit_price;
      const discount = subtotal * (line.discount_pct / 100);
      const tax = (subtotal - discount) * (line.tax_pct / 100);
      const total = subtotal - discount + tax;
      
      if (line.line_total !== total) {
        setValue(`lines.${index}.line_total`, total);
      }
    });
  }, [lines, setValue]);

  const subtotal = lines.reduce((acc, line) => acc + (line.qty * line.unit_price), 0);
  const totalDiscount = lines.reduce((acc, line) => acc + (line.qty * line.unit_price * (line.discount_pct / 100)), 0);
  const totalTax = lines.reduce((acc, line) => acc + ((line.qty * line.unit_price - (line.qty * line.unit_price * (line.discount_pct / 100))) * (line.tax_pct / 100)), 0);
  const grandTotal = subtotal - totalDiscount + totalTax;

  const onSubmit = async (data: InvoiceFormValues) => {
    try {
      const payload = {
        ...data,
        type: 'sale',
        subtotal,
        discount_amount: totalDiscount,
        tax_amount: totalTax,
        grand_total: grandTotal,
        paid_amount: data.payment_method === 'cash' ? grandTotal : 0,
        balance: data.payment_method === 'cash' ? 0 : grandTotal,
        status: 'posted'
      };
      await axios.post('http://localhost:5000/api/invoices', payload);
      toast.success('Invoice created successfully');
      onSuccess();
      onClose();
    } catch (error) {
      toast.error('Failed to create invoice');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 w-full max-w-6xl max-h-[90vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden" dir="rtl">
        <div className="p-6 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center">
          <h3 className="text-xl font-bold dark:text-white">New Sales Invoice</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors">
            <X size={24} className="text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="flex-1 overflow-y-auto p-6 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Invoice Number</label>
              <input {...register('number')} className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-primary" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Date</label>
              <input type="date" {...register('date')} className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-primary" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Customer</label>
              <select className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-primary">
                <option value="">Walk-in Customer</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Payment Method</label>
              <select {...register('payment_method')} className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-primary">
                <option value="cash">Cash</option>
                <option value="partial">Partial</option>
                <option value="credit">Credit (Deferred)</option>
              </select>
            </div>
          </div>

          <div className="border border-gray-100 dark:border-gray-700 rounded-xl overflow-hidden">
            <table className="w-full text-right">
              <thead className="bg-gray-50 dark:bg-gray-700/50">
                <tr>
                  <th className="px-4 py-3 text-sm font-semibold">#</th>
                  <th className="px-4 py-3 text-sm font-semibold">Item / Description</th>
                  <th className="px-4 py-3 text-sm font-semibold w-24">Qty</th>
                  <th className="px-4 py-3 text-sm font-semibold w-32">Price</th>
                  <th className="px-4 py-3 text-sm font-semibold w-24">Disc%</th>
                  <th className="px-4 py-3 text-sm font-semibold w-24">Tax%</th>
                  <th className="px-4 py-3 text-sm font-semibold w-32">Total</th>
                  <th className="px-4 py-3 text-sm font-semibold w-16"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                {fields.map((field, index) => (
                  <tr key={field.id}>
                    <td className="px-4 py-2 text-sm">{index + 1}</td>
                    <td className="px-4 py-2">
                      <input {...register(`lines.${index}.description`)} placeholder="Item name or code" className="w-full bg-transparent border-none outline-none text-sm" />
                    </td>
                    <td className="px-4 py-2">
                      <input type="number" {...register(`lines.${index}.qty`, { valueAsNumber: true })} className="w-full bg-transparent border-none outline-none text-sm" />
                    </td>
                    <td className="px-4 py-2">
                      <input type="number" {...register(`lines.${index}.unit_price`, { valueAsNumber: true })} className="w-full bg-transparent border-none outline-none text-sm" />
                    </td>
                    <td className="px-4 py-2">
                      <input type="number" {...register(`lines.${index}.discount_pct`, { valueAsNumber: true })} className="w-full bg-transparent border-none outline-none text-sm" />
                    </td>
                    <td className="px-4 py-2">
                      <input type="number" {...register(`lines.${index}.tax_pct`, { valueAsNumber: true })} className="w-full bg-transparent border-none outline-none text-sm" />
                    </td>
                    <td className="px-4 py-2 text-sm font-bold">
                      ${lines[index]?.line_total?.toFixed(2)}
                    </td>
                    <td className="px-4 py-2">
                      <button type="button" onClick={() => remove(index)} className="text-red-500 hover:bg-red-50 p-1 rounded transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button type="button" onClick={() => append({ product_id: 1, description: '', qty: 1, unit_price: 0, discount_pct: 0, tax_pct: 0, line_total: 0 })} className="w-full py-3 bg-gray-50 dark:bg-gray-700/30 text-primary text-sm font-medium flex items-center justify-center gap-2 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
              <Plus size={18} />
              Add Line Item (Enter)
            </button>
          </div>

          <div className="flex justify-between items-start gap-12">
            <div className="flex-1 space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Notes</label>
                <textarea {...register('notes')} rows={3} className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-primary text-sm" placeholder="Internal notes or terms..."></textarea>
              </div>
              <div className="flex gap-4">
                <button type="button" className="flex items-center gap-2 px-4 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                  <Barcode size={18} />
                  Barcode Mode (Ctrl+B)
                </button>
              </div>
            </div>

            <div className="w-80 bg-gray-50 dark:bg-gray-700/50 p-6 rounded-xl space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Subtotal</span>
                <span className="font-medium">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Discount</span>
                <span className="font-medium text-red-600">-${totalDiscount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Tax</span>
                <span className="font-medium">${totalTax.toFixed(2)}</span>
              </div>
              <div className="pt-3 border-t border-gray-200 dark:border-gray-600 flex justify-between items-center">
                <span className="font-bold">Grand Total</span>
                <span className="text-2xl font-bold text-primary dark:text-blue-400">${grandTotal.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </form>

        <div className="p-6 border-t border-gray-100 dark:border-gray-700 flex justify-end gap-4">
          <button type="button" onClick={onClose} className="px-6 py-2 border border-gray-200 dark:border-gray-700 rounded-lg font-medium hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            Cancel
          </button>
          <button type="button" className="px-6 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg font-medium hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors flex items-center gap-2">
            <Printer size={20} />
            Print PDF
          </button>
          <button onClick={handleSubmit(onSubmit)} className="px-8 py-2 bg-primary text-white rounded-lg font-bold hover:bg-primary-dark transition-colors flex items-center gap-2 shadow-lg shadow-primary/20">
            <Save size={20} />
            Save Invoice (Ctrl+S)
          </button>
        </div>
      </div>
    </div>
  );
};

export default InvoiceForm;
