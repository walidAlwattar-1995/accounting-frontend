import React from 'react';
import { useQuery } from 'react-query';
import axios from 'axios';
import { Plus, Search, BookOpen, ChevronDown, ChevronUp } from 'lucide-react';

const fetchJournal = async () => {
  const { data } = await axios.get('http://localhost:5000/api/journal');
  return data;
};

const JournalEntries = () => {
  const { data: entries, isLoading } = useQuery('journal', fetchJournal);
  const [expandedId, setExpandedId] = React.useState<number | null>(null);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold dark:text-white">Journal Entries</h2>
        <button className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-dark transition-colors flex items-center gap-2">
          <Plus size={20} />
          New Manual Entry
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
        <div className="relative max-w-md">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Search entries by number or reference..."
            className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg py-2 pr-10 pl-4 focus:ring-2 focus:ring-primary outline-none text-sm"
          />
        </div>
      </div>

      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center py-12">Loading...</div>
        ) : entries?.length > 0 ? (
          entries.map((entry: any) => (
            <div key={entry.id} className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
              <div 
                className="p-4 flex items-center justify-between cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors"
                onClick={() => setExpandedId(expandedId === entry.id ? null : entry.id)}
              >
                <div className="flex items-center gap-4">
                  <div className="p-2 bg-blue-50 dark:bg-blue-900/20 text-blue-600 rounded-lg">
                    <BookOpen size={20} />
                  </div>
                  <div>
                    <p className="font-bold dark:text-white">{entry.number}</p>
                    <p className="text-xs text-gray-500">{entry.date}</p>
                  </div>
                </div>
                <div className="flex items-center gap-8">
                  <div className="text-right">
                    <p className="text-xs text-gray-500">Reference</p>
                    <p className="text-sm font-medium dark:text-gray-300">{entry.reference || '-'}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-500">Type</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${entry.type === 'auto' ? 'bg-purple-100 text-purple-700' : 'bg-amber-100 text-amber-700'}`}>
                      {entry.type}
                    </span>
                  </div>
                  {expandedId === entry.id ? <ChevronUp size={20} className="text-gray-400" /> : <ChevronDown size={20} className="text-gray-400" />}
                </div>
              </div>
              
              {expandedId === entry.id && (
                <div className="border-t border-gray-100 dark:border-gray-700 p-4 bg-gray-50/50 dark:bg-gray-900/20">
                  <table className="w-full text-right">
                    <thead>
                      <tr className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                        <th className="px-4 py-2">Account</th>
                        <th className="px-4 py-2">Description</th>
                        <th className="px-4 py-2 w-32">Debit</th>
                        <th className="px-4 py-2 w-32">Credit</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                      {entry.lines.map((line: any) => (
                        <tr key={line.id}>
                          <td className="px-4 py-2 text-sm font-medium dark:text-gray-300">{line.account_name}</td>
                          <td className="px-4 py-2 text-sm text-gray-500">{line.description || entry.description}</td>
                          <td className="px-4 py-2 text-sm font-bold text-green-600">{line.debit > 0 ? `$${line.debit.toLocaleString()}` : '-'}</td>
                          <td className="px-4 py-2 text-sm font-bold text-red-600">{line.credit > 0 ? `$${line.credit.toLocaleString()}` : '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          ))
        ) : (
          <div className="bg-white dark:bg-gray-800 p-12 rounded-xl border border-dashed border-gray-300 dark:border-gray-700 text-center text-gray-500">
            No journal entries found.
          </div>
        )}
      </div>
    </div>
  );
};

export default JournalEntries;
