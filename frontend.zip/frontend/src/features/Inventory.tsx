import React from 'react';
import { useQuery } from 'react-query';
import axios from 'axios';
import { Plus, Search, Package, AlertTriangle, Barcode as BarcodeIcon } from 'lucide-react';

const fetchProducts = async () => {
  const { data } = await axios.get('http://localhost:5000/api/products');
  return data;
};

const Inventory = () => {
  const { data: products, isLoading } = useQuery('products', fetchProducts);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold dark:text-white">Inventory Management</h2>
        <button className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-dark transition-colors flex items-center gap-2">
          <Plus size={20} />
          Add New Product
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 flex items-center gap-4">
          <div className="p-3 bg-blue-100 text-blue-600 rounded-lg">
            <Package size={24} />
          </div>
          <div>
            <p className="text-gray-500 text-sm">Total Items</p>
            <p className="text-2xl font-bold dark:text-white">{products?.length || 0}</p>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 flex items-center gap-4">
          <div className="p-3 bg-red-100 text-red-600 rounded-lg">
            <AlertTriangle size={24} />
          </div>
          <div>
            <p className="text-gray-500 text-sm">Low Stock</p>
            <p className="text-2xl font-bold dark:text-white">
              {products?.filter((p: any) => p.current_qty <= p.min_qty).length || 0}
            </p>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 flex items-center gap-4">
          <div className="p-3 bg-purple-100 text-purple-600 rounded-lg">
            <BarcodeIcon size={24} />
          </div>
          <div>
            <p className="text-gray-500 text-sm">Total Value</p>
            <p className="text-2xl font-bold dark:text-white">
              ${products?.reduce((acc: number, p: any) => acc + (p.current_qty * p.purchase_price), 0).toLocaleString()}
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 flex flex-wrap gap-4 items-center justify-between">
        <div className="relative flex-1 min-w-[300px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Search by name, code, or barcode..."
            className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg py-2 pr-10 pl-4 focus:ring-2 focus:ring-primary outline-none text-sm"
          />
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
        <table className="w-full text-right">
          <thead className="bg-gray-50 dark:bg-gray-700/50">
            <tr>
              <th className="px-6 py-4 font-semibold text-sm">Code</th>
              <th className="px-6 py-4 font-semibold text-sm">Product Name</th>
              <th className="px-6 py-4 font-semibold text-sm">Barcode</th>
              <th className="px-6 py-4 font-semibold text-sm">Cost</th>
              <th className="px-6 py-4 font-semibold text-sm">Price</th>
              <th className="px-6 py-4 font-semibold text-sm">Qty</th>
              <th className="px-6 py-4 font-semibold text-sm">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
            {isLoading ? (
              <tr><td colSpan={7} className="px-6 py-12 text-center">Loading...</td></tr>
            ) : products?.length > 0 ? (
              products.map((p: any) => (
                <tr key={p.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium">{p.code}</td>
                  <td className="px-6 py-4 text-sm">{p.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{p.barcode || '-'}</td>
                  <td className="px-6 py-4 text-sm">${p.purchase_price.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm font-bold">${p.sale_price.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`font-bold ${p.current_qty <= p.min_qty ? 'text-red-600' : 'text-green-600'}`}>
                      {p.current_qty}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      p.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {p.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center text-gray-500">No products found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Inventory;
