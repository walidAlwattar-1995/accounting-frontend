import React from 'react';
import { useQuery } from 'react-query';
import axios from 'axios';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Users, 
  ShoppingBag, 
  Wallet 
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';

const fetchDashboardData = async () => {
  const { data } = await axios.get('http://localhost:5000/api/dashboard');
  return data;
};

const StatCard = ({ title, value, icon: Icon, color }: any) => (
  <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
    <div className="flex items-center justify-between mb-4">
      <div className={`p-3 rounded-lg ${color} bg-opacity-10`}>
        <Icon className={color.replace('bg-', 'text-')} size={24} />
      </div>
    </div>
    <p className="text-gray-500 text-sm font-medium">{title}</p>
    <p className="text-2xl font-bold mt-1 dark:text-white">{value}</p>
  </div>
);

const Dashboard = () => {
  const { data, isLoading } = useQuery('dashboard', fetchDashboardData);

  if (isLoading) return <div className="p-4">Loading dashboard...</div>;

  const stats = data?.stats || {
    totalSales: 0,
    totalPurchases: 0,
    netProfit: 0,
    receivables: 0,
    payables: 0,
    treasuryBalance: 0
  };

  const chartData = [
    { name: 'Jan', sales: 4000, purchases: 2400 },
    { name: 'Feb', sales: 3000, purchases: 1398 },
    { name: 'Mar', sales: 2000, purchases: 9800 },
    { name: 'Apr', sales: 2780, purchases: 3908 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold dark:text-white">Dashboard Overview</h2>
        <div className="flex gap-2">
          <select className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-4 py-2 text-sm outline-none">
            <option>Today</option>
            <option>This Week</option>
            <option>This Month</option>
            <option>This Year</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
        <StatCard title="Total Sales" value={`$${stats.totalSales.toLocaleString()}`} icon={TrendingUp} color="bg-green-500" />
        <StatCard title="Total Purchases" value={`$${stats.totalPurchases.toLocaleString()}`} icon={TrendingDown} color="bg-red-500" />
        <StatCard title="Net Profit" value={`$${stats.netProfit.toLocaleString()}`} icon={DollarSign} color="bg-blue-500" />
        <StatCard title="Receivables" value={`$${stats.receivables.toLocaleString()}`} icon={Users} color="bg-amber-500" />
        <StatCard title="Payables" value={`$${stats.payables.toLocaleString()}`} icon={ShoppingBag} color="bg-purple-500" />
        <StatCard title="Treasury" value={`$${stats.treasuryBalance.toLocaleString()}`} icon={Wallet} color="bg-emerald-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
          <h3 className="text-lg font-bold mb-6 dark:text-white">Sales vs Purchases</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="sales" fill="#1e40af" radius={[4, 4, 0, 0]} />
                <Bar dataKey="purchases" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
          <h3 className="text-lg font-bold mb-6 dark:text-white">Profit Trend</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="sales" stroke="#1e40af" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
        <div className="p-6 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center">
          <h3 className="text-lg font-bold dark:text-white">Recent Transactions</h3>
          <button className="text-primary text-sm font-medium hover:underline">View All</button>
        </div>
        <table className="w-full text-right">
          <thead className="bg-gray-50 dark:bg-gray-700/50">
            <tr>
              <th className="px-6 py-4 font-semibold text-sm">Number</th>
              <th className="px-6 py-4 font-semibold text-sm">Date</th>
              <th className="px-6 py-4 font-semibold text-sm">Type</th>
              <th className="px-6 py-4 font-semibold text-sm">Amount</th>
              <th className="px-6 py-4 font-semibold text-sm">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
            {data?.recentTransactions?.length > 0 ? (
              data.recentTransactions.map((tx: any) => (
                <tr key={tx.number} className="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium">{tx.number}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{tx.date}</td>
                  <td className="px-6 py-4 text-sm capitalize">{tx.type}</td>
                  <td className="px-6 py-4 text-sm font-bold">${tx.amount.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      tx.status === 'posted' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {tx.status}
                    </span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-gray-500">No recent transactions</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Dashboard;
