import React, { useState } from 'react';
import { useQuery } from 'react-query';
import axios from 'axios';
import { Plus, Search, Filter, MoreVertical, Download, Printer } from 'lucide-react';
import InvoiceForm from './InvoiceForm';

const fetchInvoices = async () => {
  const { data } = await axios.get('http://localhost:5000/api/invoices?type=sale');
  return data;
};

const SalesList = () => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const { data: invoices, isLoading, refetch } = useQuery('sales-invoices', fetchInvoices);

  return (
    <div className="space-y-6">
      {isFormOpen && (
        <InvoiceForm 
          onClose={() => setIsFormOpen(false)} 
          onSuccess={() => refetch()} 
        />
      )}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold dark:text-white">Sales Invoices</h2>
        <button 
          onClick={() => setIsFormOpen(true)}
          className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-dark transition-colors flex items-center gap-2"
        >
          <Plus size={20} />
          New Invoice
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 flex flex-wrap gap-4 items-center justify-between">
        <div className="relative flex-1 min-w-[300px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Search by invoice number, customer..."
            className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg py-2 pr-10 pl-4 focus:ring-2 focus:ring-primary outline-none text-sm"
          />
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            <Filter size={18} />
            Filters
          </button>
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            <Download size={18} />
            Export
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
        <table className="w-full text-right">
          <thead className="bg-gray-50 dark:bg-gray-700/50">
            <tr>
              <th className="px-6 py-4 font-semibold text-sm">Invoice No.</th>
              <th className="px-6 py-4 font-semibold text-sm">Date</th>
              <th className="px-6 py-4 font-semibold text-sm">Customer</th>
              <th className="px-6 py-4 font-semibold text-sm">Total</th>
              <th className="px-6 py-4 font-semibold text-sm">Paid</th>
              <th className="px-6 py-4 font-semibold text-sm">Balance</th>
              <th className="px-6 py-4 font-semibold text-sm">Status</th>
              <th className="px-6 py-4 font-semibold text-sm">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
            {isLoading ? (
              <tr><td colSpan={8} className="px-6 py-12 text-center">Loading...</td></tr>
            ) : invoices?.length > 0 ? (
              invoices.map((inv: any) => (
                <tr key={inv.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium">{inv.number}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{inv.date}</td>
                  <td className="px-6 py-4 text-sm">{inv.customer_name || 'Walk-in Customer'}</td>
                  <td className="px-6 py-4 text-sm font-bold">${inv.grand_total.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm text-green-600">${inv.paid_amount.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm text-red-600">${inv.balance.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      inv.status === 'posted' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {inv.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <div className="flex items-center gap-2">
                      <button className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-colors">
                        <Printer size={16} className="text-gray-500" />
                      </button>
                      <button className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-colors">
                        <MoreVertical size={16} className="text-gray-500" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={8} className="px-6 py-12 text-center text-gray-500">No sales invoices found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SalesList;
