import React from 'react';
import { useQuery } from 'react-query';
import axios from 'axios';
import { Plus, Search, User, Phone, Mail, MapPin } from 'lucide-react';

const fetchCustomers = async () => {
  const { data } = await axios.get('http://localhost:5000/api/customers');
  return data;
};

const Customers = () => {
  const { data: customers, isLoading } = useQuery('customers', fetchCustomers);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold dark:text-white">Customers</h2>
        <button className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-dark transition-colors flex items-center gap-2">
          <Plus size={20} />
          Add New Customer
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
        <div className="relative max-w-md">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Search customers..."
            className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg py-2 pr-10 pl-4 focus:ring-2 focus:ring-primary outline-none text-sm"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          <div className="col-span-full text-center py-12">Loading...</div>
        ) : customers?.length > 0 ? (
          customers.map((c: any) => (
            <div key={c.id} className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                  <User size={24} />
                </div>
                <div>
                  <h3 className="font-bold dark:text-white">{c.name}</h3>
                  <p className="text-xs text-gray-500">{c.code}</p>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Phone size={16} />
                  <span>{c.phone || 'No phone'}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Mail size={16} />
                  <span>{c.email || 'No email'}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <MapPin size={16} />
                  <span className="truncate">{c.address || 'No address'}</span>
                </div>
              </div>
              <div className="pt-4 border-t border-gray-100 dark:border-gray-700 flex justify-between items-center">
                <span className="text-xs text-gray-500">Balance</span>
                <span className="font-bold text-red-600">${c.opening_balance.toLocaleString()}</span>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full bg-white dark:bg-gray-800 p-12 rounded-xl border border-dashed border-gray-300 dark:border-gray-700 text-center text-gray-500">
            No customers found. Click "Add New Customer" to get started.
          </div>
        )}
      </div>
    </div>
  );
};

export default Customers;
