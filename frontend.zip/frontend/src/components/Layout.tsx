import React from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from './Header';
import { useKeyboardShortcuts } from '../hooks/useKeyboardShortcuts';
import { toast } from 'react-hot-toast';

const Layout = () => {
  const navigate = useNavigate();

  useKeyboardShortcuts({
    'ctrl+f': () => {
      const searchInput = document.querySelector('header input') as HTMLInputElement;
      if (searchInput) searchInput.focus();
    },
    'ctrl+n': () => {
      toast.info('Opening new document...', { icon: '📝' });
      // Logic to open new invoice/entry based on current route
    },
    'ctrl+s': () => {
      toast.success('Saving changes...');
    },
  });
  return (
    <div className="flex min-h-screen bg-gray-50 dark:bg-gray-900" dir="rtl">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        <main className="flex-1 p-6 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;
